QueueUrl = "https://sqs.<region>.amazonaws.com/<iam-id>/<queue-name>"
